# sql注入

## 基本概念

sql注入是将sql代码插入或添加到应用到输入参数中,之后将这些参数传递给后台的sql服务器加以解析并执行的攻击.

攻击者能够修改sql语句,该进程将与执行命令的组件(如数据库服务器,应用服务器或web服务器)拥有相同的权限

web应用无法确保从web表单,cookie,输入参数等收到的值传递给sql查询之前对其进行验证,通常会出现sql注入漏洞



## 分类

1.union注入

2.boolean注入

3.报错注入

主键重复,整形溢出,xpath处理函数,列名重复,几何函数

4.时间注入

sleep,benchmark(1000,sha(1)),笛卡尔积,get_lock,Rlink

5.堆叠查询注入

6.二次注入

7.宽字节注入

8.cookie注入

9.XFF注入

10.base64注入

#### 时间注入

1.sleep

2.benchmark 重复执行一个大量耗时的命令

3.笛卡尔积(这种方法又叫做heavy query),通过选定一个大表来做笛卡尔积,但这种方式执行时间会呈几何倍数提升

select count(*) from information_schema.columa A, information_schema.columa B

4.get_lock,不一定所有的网站都能使用(但是延时精确可控)

当我们锁定一个变量后,另一个session再次包含这个变量就会造成延迟,例如

select get_lock('A',1); 0.00sec

select get_lock('A',5); 5.00sec

利用场景有限,需要提供长连接,apache+php中要用mysql_pconnect连接数据库

5.正则bug

正则匹配在匹配较长字符串但自由度较高的字符串时,会造成大量计算,通过rpad,repeat构造长字符,加以计算量大大pattern,控制字符长度可以造成延迟

select rpad('a',49999,'a')	RLINK concatcrepeat('(a*)+',30),b');

#### 报错注入

1.主键重复 利用的函数 floor(rand(0)*2) (函数会被执行5次),group by

数据表中至少要有三条数据才会报错

2.整形溢出 适用版本 大于等于5.5.5版本 ~0 和 exp()函数 等

3.xpath处理函数 (extractvalue 和 updatexml) 5.1版本

4.列名重复    mysql列名重复会报错,利用name_const制造一个列

select * from (select name_const (version(),0))x;

name_const 要求参数必须是常量

利用列名不可重复,可以用join爆破列名

select * from (select * from user a join user b)c;

5.几何函数

geometycollection(),multipoint(),polygon(),multipolygon(),linestring(),multilinestring()

## 防御sql注入

123123

## sql写shell

123213