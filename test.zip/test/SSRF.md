# SSRF 服务端请求伪造

由攻击者发起请求,由服务端发起请求的漏洞.

一般情况下ssrf攻击的目标是内网无法访问的内部系统

正是因为请求是服务端发起的,所以服务端能请求到与自身相连而与外网隔离的内部系统

## 漏洞原理

服务端提供了从其他服务器应用获取数据的功能并且没有对目标地址做过滤与限制

例如,攻击者操控服务端从指定url地址获取网页文本文件内容,加载指定地址图片等

ssrf利用存在缺陷的web应用作为代理攻击远程和本地的服务器

## 攻击方式

1.对外网,服务器所在内网,本地进行端口扫描,获取服务的banner信息

2.攻击运行在内网或本地的程序(比如溢出)

3.对内网web应用进行指纹识别,识别企业内部的资产信息,通过访问默认文件实现

4.攻击内外网web应用,主要是使用http get请求就可以实现的攻击(struts2,sqli)

5.利用file协议读取本地文件等还可以用dict,gopher协议等

## 出现的场景

1.能对外发起网络请求的地方

2.从远程服务器请求资源(upload from url,import & export RSS feed)

3.数据库内置的功能(oracle,mongoDB,mssql,postgres,couchDB)

4.webmail收取其他邮箱邮件(pop3,imap,smtp)

5.文件处理,编码处理,属性信息处理(ffmpeg,imagemagic,docx,pdf,xml)

## 修复方式

1.限制请求的端口只能为web端口,只允许http和https的请求

2.限制不能访问内网的ip,以防止对内网进行攻击

3.屏蔽返回的详细信息

4.服务器开启OpenSSL,无法交互利用

5.服务器需要鉴权,(cookies & user:pass)不能完美利用

## 常用的后端实现(函数)

`file_get_content`;`fsockopen()`;`curl_exec`