# csrf 跨站请求伪

由于目标站无token或referer防御,导致用户的敏感操作的每个参数被攻击者获知,攻击者可以伪造一个完全一样的用户身份来对服务器进行请求,达到恶意目的

利用cookie等登录状态,达到无需获取用户权限,就能伪造用户请求,对用户数据进行操作

## 前提条件

1.目标站点不能检查referer头,或允许攻击者的浏览器进行referer欺骗

2.攻击者必须在目标站点找到一个表单的提交入口,或者有类似的url

3.必须知道所有表单或者url参数中正确的值

4.必须诱导受害者访问有恶意代码的页面,并且受害者已经登录目标站点

## csrf和xss最大的区别

xss:跨站点的请求			csrf:请求的伪造

## csrf类型

请求类型分为post和get型

攻击方式分为html csrf;	json hijacking;	flash csrf;等

#### html csrf

最常见的csrf攻击,利用html元素发出csrf请求

html中能设置 src/href 等链接地址的标签都可以发起一个get请求

```html
<link href = ""></link>
<img src = ""></img>
<img lowsrc = ""></img>
<img dynsrc = ""></img>
<iframe src = ""></iframe>
<frame src = ""></frame>
<script src = ""></script>
<bgsound src = ""></bgsound>
<embed src= ""></embed>
<video src = ""></video>
<audio src = ""></audio>
<a href = ""></a>
<table background = ""></table>
<meta http-equiv= "refresh" content="0; url ="></meta>
```

css中的background:url("")

也可以使用表单来对post型的请求进行伪造

```html
<form action = "http://www.example.com/register" id = "register" method = "post">
    <input type=text name = "username" value = "" />
    <input type=password name = "password" value = "" />
</form>
<script>
	var f = document.getElementById("register");
    f.inputs[0].value = "test";
    f.inputs[1].value = "passwd";
    f.submit();
</script>
```

#### flash csrf

flash中可以通过getURL,loadVars.POST等方式来发起请求

## 防御方式

1.验证码(不完全解决).验证码强制用户必须和应用进行交互,才能完成最终的请求,在一定程度上遏制csrf攻击

2.查看referer(不完全解决).查看请求源,一般referer的值必须为当前表单所在页面,若不在此页面,则可能遭受csrf攻击.

但是服务器并非随时都能获取得referer,只能监控是否发生,并不能防范统一域上的csrf攻击

3.设置token值,csrf本质上就是攻击者猜到了你的重要参数,提交请求时服务器只需要验证表单中token与用户session中的token是否一致即可,token可以放在用户的session或者浏览器的cookies中

​	1.用户登录时随机生成一段字符串,存储在session中

​	2.提交请求时,服务器中session与提交token对比,如果相同,则认为正常请求,不是则可能是csrf

​	3.更新token



4.重要操作使用post(增加攻击难度,不能直接在url中得到参数)

如果token出现在url中,则可能会通过referer泄露,尽量吧token放在表单中,敏感操作由get该为post,以表单或ajax形式提交,避免token泄露

















