# xss

## 分类和概念

同源策略:限制了来自不同源的document或脚本对当前document读取或设置某些属性

影响源的因素:host,子域名,协议,端口

csp:由服务器端返回一个http头,并在其中描述页面应该遵守的安全策略(因为xss在没有插件帮助的情况下不能修改http头)

### 反射型xss:把用户输入的数据反射给浏览器,需要让用户点击恶意链接

储存在URL

插入点在HTML

### 存储型xss:把用户输入的数据存储在服务器,很稳定

储存在后端数据库

插入点在HTML

### dom型xss:特殊的反射型xss(出现在js代码中的xss漏洞)

储存在后端数据库,前端储存,URL

插入点在前端JS

html标签都是节点,节点组成了dom的整体结构,节点可以通过js访问,创建,修改,删除.客户端的脚本程序可以通过dom动态修改页面内容,从客户端获取dom的数据并在本地执行.

由于dom是在客户端修改节点的,所有dom型xss不需要与服务器进行交互,只发生在客户端处理数据的阶段

(用户请求一个url,包含xss代码,服务器响应不包含攻击者脚本,当用户浏览器处理这个响应时,dom对象处理xss代码,导致xss被触发)

## 可以通过哪些方式触发

1.来自用户的UGC信息

2.来自第三方的链接

3.URL参数

4.POST参数

5.referer 来自于不可信的来源

6.cookie 来自于其他子域注入

## 注入的一些方法

1.在html内嵌的一些文本中,恶意内容以script标签形式形成注入

2.在内联的js中,拼接的数据突破了原本的限制(字符串,变量,方法名)

3.在标签属性中,恶意内容包含引号,可以突破属性值限制,注入其他属性或者标签

4.在标签的href,src属性中,包含`JavaScript:`可执行代码

5.在onload,onerror,onclick等事件中,注入不受控制的代码

6.在style属性和标签中,包含了类似`background-image:url("javacript:...");`这样的代码

7.在style属性和标签中,包含了类似`expression(...)`的css表达式代码

## 修复的一些方式和代码

1.HTML转义

example: escapeHTML()转义

```html
<input type = "text" value = "<% = getParameter("keyword")%>">
```

修改后的代码

```html
<input type = "text" value = "<%=escapeHTML(getParameter("keyword"))%>">
```

2.用户输入内容都在固定的容器或属性内,以文本形式展示

3.对于链接跳转,如<a herf = "xxx" 或location.href="xxx"要检验其内容,禁止javascript:开头的链接,和非法scheme

4.纯前端渲染 代码与数据分离

#### 什么是纯前端渲染?

​	1.浏览器加载一个静态的html,此html不包含任何业务相关数据

​	2.浏览器执行html中的js

​	3.js通过ajax加载业务数据,调用dom api更新到页面上,纯前端渲染中,我们会明确告诉浏览器下面要设置的内容是文本(.innerText),属性(.setAttribute),还是样式(.style),浏览器不会被轻易欺骗.

​	但是纯前端渲染还需要注意避免dom型xss(例如onload事件和herf中的javascript:xxx)

#### 预防dom型xss

使用 innerHTML,outerHTML,document.write()时要小心,不把不可信数据作为html插到页面上,尽量使用textContent,setAttribute()等

如果使用vue/React 技术栈,并且不使用v-html/dangerouslySetInnerHTML功能在前端render阶段避免innerHTML,outerHTML的xss隐患

dom中的内联事件监听器,location,onclick,onerror,onload,onmouseover,\<a\>标签herf属性,javascript的eval(),setTimeout(),setInterval()等,都能把字符串作为代码执行,不可信数据拼接到字符串中传给这些api有隐患

## 其他xss防范措施

1.csp

在渲染和执行javascript时,通过转义可以防止xss发生

严格的csp在xss的防范起到以下作用

​	1.禁止加载外域代码,防止复杂的攻击逻辑

​	2.禁止外域提交,网站被攻击后,用户的数据不会泄露到外域

​	3.禁止内联脚本执行

​	4.禁止未授权脚本执行

2.输入内容长度控制

对于不受信任的输入,都限定一个合理的长度,无法防止xss发生,但能提高攻击难度

3.http only cookie

禁止js读取某些敏感cookie,攻击者完成xss注入后也无法窃取此cookie

4.验证码

防止脚本冒充用户提交危险操作



## 其他

Q:在用户提交时,前端过滤输入,然后提交到后端,是否可行

A:不可行,一旦攻击者绕过前端过滤,直接构造请求,就可以提交恶意代码

Q:在后端写入数据库前进行过滤,再把安全的内容返回前端呢

A:可行,但问题在于在提交阶段,我们不确定内容要输入到哪里\

1.用户输入内容可能同时给前端,后端,一旦经过escapeHTML,客户端的内容就会变成乱码

2.在前端不同位置所需代码不同







